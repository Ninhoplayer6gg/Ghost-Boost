# Changelog

## 1.0.0-beta
- Added world warm-up guard for FPS-based tuning.
- Added SessionGuard unclean-session hint and optional safe-mode policy.
- Added full support-report writer and `/ghostboost report`.
- First combined build intended for structured Fisk/Android testing.

## 0.9.0-alpha
- Persistent per-device AutoTune.

## 0.8.0-alpha
- Fisk Mobile Guard and HeroPack diagnostics.

## 0.7.0-alpha
- Frame-budget engine with P99/stutter awareness and adaptive hysteresis.
