package com.ghostboost.command;

import java.util.List;

import com.ghostboost.GhostBoost;
import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.compat.FiskContentProfile;
import com.ghostboost.compat.FiskRuntimeTuner;
import com.ghostboost.profile.BenchmarkManager;
import com.ghostboost.profile.AutoTuneManager;
import com.ghostboost.profile.DiagnosticEngine;
import com.ghostboost.profile.FrameTimeProfiler;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;
import com.ghostboost.profile.SupportReport;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

public final class GhostCommand extends CommandBase {

    @Override
    public String getCommandName() { return "ghostboost"; }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/ghostboost status | profile <mode> | diagnose | report | benchmark <...> | autotune <...> | restore";
    }

    @Override
    public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length >= 2 && "profile".equalsIgnoreCase(args[0])) {
            PerformanceProfile profile = PerformanceProfile.fromString(args[1]);
            ProfileManager.INSTANCE.setProfile(profile);
            sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost profile: "
                + EnumChatFormatting.WHITE + ProfileManager.INSTANCE.getEffective()));
            return;
        }


        if (args.length >= 1 && "report".equalsIgnoreCase(args[0])) {
            java.io.File report = SupportReport.write();
            sender.addChatMessage(new ChatComponentText(report == null
                ? EnumChatFormatting.GRAY + "GhostBoost could not write the report in this runtime."
                : EnumChatFormatting.AQUA + "GhostBoost report: " + report.getAbsolutePath()));
            return;
        }

        if (args.length >= 1 && "diagnose".equalsIgnoreCase(args[0])) {
            List<String> lines = DiagnosticEngine.buildRecommendations();
            sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost diagnostics"));
            for (String line : lines) sender.addChatMessage(new ChatComponentText(EnumChatFormatting.GRAY + "- " + line));
            return;
        }

        if (args.length >= 2 && "benchmark".equalsIgnoreCase(args[0])) {
            if ("start".equalsIgnoreCase(args[1])) {
                int seconds = 30;
                if (args.length >= 3) {
                    try { seconds = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                }
                BenchmarkManager.INSTANCE.start(seconds);
                sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost benchmark started for "
                    + BenchmarkManager.INSTANCE.getTargetSeconds() + " seconds. Play normally."));
                return;
            }
            if ("result".equalsIgnoreCase(args[1])) {
                sender.addChatMessage(new ChatComponentText(EnumChatFormatting.WHITE + BenchmarkManager.INSTANCE.getLastResult()));
                return;
            }
        }


        if (args.length >= 1 && "autotune".equalsIgnoreCase(args[0])) {
            if (args.length >= 2 && "start".equalsIgnoreCase(args[1])) {
                int seconds = 60;
                if (args.length >= 3) {
                    try { seconds = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
                }
                AutoTuneManager.INSTANCE.start(seconds);
                sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost AutoTune started for "
                    + AutoTuneManager.INSTANCE.getTargetSeconds() + " seconds. Move/fly/fight normally."));
                return;
            }
            if (args.length >= 2 && "reset".equalsIgnoreCase(args[1])) {
                AutoTuneManager.INSTANCE.reset();
                sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost learned profile reset."));
                return;
            }
            sender.addChatMessage(new ChatComponentText(EnumChatFormatting.WHITE + AutoTuneManager.INSTANCE.getLastSummary()));
            return;
        }

        if (args.length >= 1 && "restore".equalsIgnoreCase(args[0])) {
            PerformanceController.INSTANCE.restoreBaseline();
            sender.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost restored the captured session baseline."));
            return;
        }

        showStatus(sender);
    }

    private void showStatus(ICommandSender sender) {
        PlatformProfile p = PlatformProfile.INSTANCE;
        PerformanceController perf = PerformanceController.INSTANCE;
        FrameTimeProfiler ft = FrameTimeProfiler.INSTANCE;

        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.AQUA + "GhostBoost " + GhostBoost.VERSION + EnumChatFormatting.GRAY + " — Beta 1.0"));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Profile: " + EnumChatFormatting.WHITE + ProfileManager.INSTANCE.getEffective()
                + EnumChatFormatting.GRAY + " | Mobile: " + EnumChatFormatting.WHITE + p.isMobileLike()));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "GPU: " + EnumChatFormatting.WHITE + p.getGlRenderer()));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Renderer path: " + EnumChatFormatting.WHITE
                + CompatibilityEngine.INSTANCE.getRendererType()));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "FPS: " + EnumChatFormatting.WHITE + perf.getLastFps()
                + EnumChatFormatting.GRAY + " | Heap: " + EnumChatFormatting.WHITE
                + Math.round(perf.getLastMemoryRatio() * 100D) + "% (" + perf.getMemoryState() + ")"));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Frame budget: " + EnumChatFormatting.WHITE + perf.getFrameBudgetState()
                + EnumChatFormatting.GRAY + " | Stutter: " + EnumChatFormatting.WHITE
                + Math.round(ft.getStutterRate() * 100D) + "%"));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "World warmup: " + EnumChatFormatting.WHITE + perf.getWorldSampleAge() + "/"
                + com.ghostboost.config.GhostConfig.worldWarmupSeconds + " sec"));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Frame: " + EnumChatFormatting.WHITE + String.format("%.1f ms", ft.getAverageMs())
                + EnumChatFormatting.GRAY + " | P95: " + EnumChatFormatting.WHITE + String.format("%.1f ms", ft.getPercentileMs(95D))
                + EnumChatFormatting.GRAY + " | P99: " + EnumChatFormatting.WHITE + String.format("%.1f ms", ft.getPercentileMs(99D))));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Adjustments: " + EnumChatFormatting.WHITE + perf.getAdjustments()
                + EnumChatFormatting.GRAY + " | Baseline chunks: " + EnumChatFormatting.WHITE + perf.getBaselineRenderDistance()));
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "Fisk: " + EnumChatFormatting.WHITE
                + (FiskCompat.isLoaded() ? FiskCompat.getDetectedId() + " " + FiskCompat.getDetectedVersion() : "not detected")));
        if (FiskCompat.isLoaded()) {
            FiskContentProfile content = FiskContentProfile.INSTANCE;
            sender.addChatMessage(new ChatComponentText(
                EnumChatFormatting.GRAY + "HeroPacks: " + EnumChatFormatting.WHITE + content.getPackCount()
                    + EnumChatFormatting.GRAY + " / " + EnumChatFormatting.WHITE + content.getTotalMb() + " MB"
                    + EnumChatFormatting.GRAY + " | Fisk guard changes: " + EnumChatFormatting.WHITE
                    + FiskRuntimeTuner.INSTANCE.getChanges()));
        }
        sender.addChatMessage(new ChatComponentText(
            EnumChatFormatting.GRAY + "AutoTune: " + EnumChatFormatting.WHITE
                + (AutoTuneManager.INSTANCE.isRunning() ? "running " + AutoTuneManager.INSTANCE.getSamples() + "/"
                    + AutoTuneManager.INSTANCE.getTargetSeconds() : AutoTuneManager.INSTANCE.getLastSummary())));
        if (BenchmarkManager.INSTANCE.isRunning()) {
            sender.addChatMessage(new ChatComponentText(EnumChatFormatting.GRAY + "Benchmark: " + EnumChatFormatting.WHITE
                + BenchmarkManager.INSTANCE.getSamples() + "/" + BenchmarkManager.INSTANCE.getTargetSeconds() + " sec"));
        }
    }
}
