package com.ghostboost.compat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** Conservative runtime tuning for Fisk on mobile translation renderers. */
public final class FiskRuntimeTuner {

    public static final FiskRuntimeTuner INSTANCE = new FiskRuntimeTuner();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Fisk");

    private int changes;
    private FrameBudgetState lastState = FrameBudgetState.HEALTHY;

    private FiskRuntimeTuner() {}

    public void onRendererReady() {
        FiskContentProfile.INSTANCE.refresh();
    }

    public void onSample(FrameBudgetState state) {
        lastState = state == null ? FrameBudgetState.HEALTHY : state;
        if (!GhostConfig.fiskCompatibility || !GhostConfig.fiskAdaptiveEffects || !FiskCompat.isLoaded()) return;
        if (!PlatformProfile.INSTANCE.isMobileLike()) return;
        RendererType renderer = CompatibilityEngine.INSTANCE.getRendererType();
        if (!isTranslationLayer(renderer)) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null || mc.theWorld == null) return;
        GameSettings settings = mc.gameSettings;
        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();

        if (lastState == FrameBudgetState.SEVERE && settings.particleSetting < 1) {
            settings.particleSetting = 1;
            changes++;
            LOG.info("Fisk mobile guard reduced particles during severe frame pressure.");
        }
        if (profile == PerformanceProfile.PERFORMANCE && settings.advancedOpengl) {
            settings.advancedOpengl = false;
            changes++;
        }
    }

    private boolean isTranslationLayer(RendererType type) {
        return type == RendererType.MOBILEGLUES || type == RendererType.ZINK || type == RendererType.VIRGL
            || type == RendererType.GL4ES || type == RendererType.ANGLE || type == RendererType.SOFTWARE;
    }

    public int getChanges() { return changes; }
    public FrameBudgetState getLastState() { return lastState; }
}
