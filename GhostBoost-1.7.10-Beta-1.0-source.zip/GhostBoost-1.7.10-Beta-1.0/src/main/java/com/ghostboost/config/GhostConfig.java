package com.ghostboost.config;

import java.io.File;

import net.minecraftforge.common.config.Configuration;

public final class GhostConfig {

    private static File configDirectory;

    public static boolean enabled = true;
    public static boolean forceMobileMode = false;
    public static boolean adaptiveRenderDistance = true;
    public static boolean adaptiveParticles = true;
    public static boolean adaptiveRecovery = true;
    public static boolean allowFancyGraphicsFallback = false;
    public static boolean emergencyGc = false;
    public static boolean fiskCompatibility = true;
    public static boolean fiskAdaptiveEffects = true;
    public static boolean rendererCompatibilityMode = true;
    public static boolean autoApplyLearnedProfile = true;
    public static boolean safeModeAfterUncleanSession = false;
    public static int targetFps = 30;
    public static int minRenderDistance = 4;
    public static int fpsSampleSeconds = 12;
    public static int recoverySeconds = 20;
    public static int recoveryFpsMargin = 8;
    public static int memoryAdjustmentCooldownSeconds = 8;
    public static int performanceRenderDistanceCap = 6;
    public static int qualityChangeCooldownSeconds = 6;
    public static int fiskHeavyPackCount = 12;
    public static int fiskHeavyPackMb = 128;
    public static int worldWarmupSeconds = 12;
    public static String defaultProfile = "auto";
    public static double warningMemoryRatio = 0.80D;
    public static double criticalMemoryRatio = 0.90D;

    private GhostConfig() {}

    public static void load(File file) {
        configDirectory = file == null ? null : file.getParentFile();
        Configuration cfg = new Configuration(file);
        try {
            cfg.load();
            enabled = cfg.getBoolean("enabled", "general", true,
                "Master switch for GhostBoost runtime optimizations.");
            forceMobileMode = cfg.getBoolean("forceMobileMode", "android", false,
                "Force Android/mobile tuning even when the launcher cannot be detected automatically.");
            adaptiveRenderDistance = cfg.getBoolean("adaptiveRenderDistance", "performance", true,
                "Reduce render distance one step at a time when sustained FPS is below the target.");
            adaptiveParticles = cfg.getBoolean("adaptiveParticles", "performance", true,
                "Reduce particles when heap pressure becomes critical.");
            adaptiveRecovery = cfg.getBoolean("adaptiveRecovery", "performance", true,
                "Gradually restore render distance and particles after sustained stable performance.");
            allowFancyGraphicsFallback = cfg.getBoolean("allowFancyGraphicsFallback", "performance", false,
                "Allow GhostBoost to disable Fancy Graphics during severe memory pressure.");
            emergencyGc = cfg.getBoolean("emergencyGc", "memory", false,
                "Allow a rare explicit GC during extreme heap pressure. Can cause a visible hitch.");
            fiskCompatibility = cfg.getBoolean("fiskCompatibility", "compatibility", true,
                "Enable conservative compatibility behavior when Fisk's Superheroes is present.");
            fiskAdaptiveEffects = cfg.getBoolean("fiskAdaptiveEffects", "compatibility", true,
                "Allow extra particle pressure control when Fisk is active on a mobile translation renderer.");
            rendererCompatibilityMode = cfg.getBoolean("rendererCompatibilityMode", "compatibility", true,
                "Classify translation renderers and apply conservative mobile compatibility fallbacks.");
            autoApplyLearnedProfile = cfg.getBoolean("autoApplyLearnedProfile", "profiles", true,
                "Apply a previously learned AutoTune result when the hardware/renderer/Fisk fingerprint matches.");
            safeModeAfterUncleanSession = cfg.getBoolean("safeModeAfterUncleanSession", "compatibility", false,
                "If enabled, AUTO starts in Compatibility profile after an unclean previous session. Disabled by default because Android may kill apps normally.");
            targetFps = cfg.getInt("targetFps", "performance", 30, 15, 120,
                "Target FPS used by the adaptive controller.");
            minRenderDistance = cfg.getInt("minRenderDistance", "performance", 4, 2, 16,
                "GhostBoost will never reduce render distance below this value.");
            fpsSampleSeconds = cfg.getInt("fpsSampleSeconds", "performance", 12, 4, 60,
                "How long FPS must remain low before GhostBoost reduces render distance.");
            recoverySeconds = cfg.getInt("recoverySeconds", "performance", 20, 5, 120,
                "Stable seconds required before GhostBoost restores one quality step.");
            recoveryFpsMargin = cfg.getInt("recoveryFpsMargin", "performance", 8, 2, 30,
                "FPS headroom above the target required for quality recovery.");
            memoryAdjustmentCooldownSeconds = cfg.getInt("memoryAdjustmentCooldownSeconds", "memory", 8, 2, 60,
                "Minimum seconds between destructive memory-pressure quality reductions.");
            performanceRenderDistanceCap = cfg.getInt("performanceRenderDistanceCap", "profiles", 6, 2, 16,
                "Maximum chunk render distance applied when Performance profile is selected.");
            qualityChangeCooldownSeconds = cfg.getInt("qualityChangeCooldownSeconds", "performance", 6, 2, 30,
                "Minimum seconds between adaptive quality changes to prevent oscillation.");
            fiskHeavyPackCount = cfg.getInt("fiskHeavyPackCount", "compatibility", 12, 1, 200,
                "HeroPack count considered heavy for diagnostics.");
            fiskHeavyPackMb = cfg.getInt("fiskHeavyPackMb", "compatibility", 128, 16, 4096,
                "Total Fisk HeroPack size in MB considered heavy for diagnostics.");
            worldWarmupSeconds = cfg.getInt("worldWarmupSeconds", "performance", 12, 0, 60,
                "Seconds after entering a world before FPS-based quality reductions begin. Memory protection remains active.");
            defaultProfile = cfg.getString("defaultProfile", "profiles", "auto",
                "Default session profile: auto, compatibility, balanced or performance.");
            warningMemoryRatio = cfg.getFloat("warningMemoryRatio", "memory", 0.80F, 0.50F, 0.98F,
                "Heap usage ratio that begins warning/monitoring behavior.");
            criticalMemoryRatio = cfg.getFloat("criticalMemoryRatio", "memory", 0.90F, 0.60F, 0.99F,
                "Heap usage ratio that allows emergency performance fallbacks.");
        } finally {
            if (cfg.hasChanged()) cfg.save();
        }
    }

    public static File getConfigDirectory() {
        return configDirectory;
    }
}
