# GhostBoost 1.7.10 — Beta 1.0

GhostBoost is an experimental performance + compatibility layer for Minecraft Java 1.7.10 on Android-class devices, initially targeting Forge + Fisk's Superheroes.

## Beta 1.0 — First serious test build

Includes everything from 0.1–0.9 plus:

- Frame-budget engine using FPS, P95, P99 and stutter rate.
- Adaptive render distance, particles and recovery with cooldown/hysteresis.
- Fisk Mobile Guard and read-only HeroPack load profiling.
- Persistent per-device AutoTune with GPU/renderer/Fisk fingerprinting.
- World warm-up window: startup/chunk-load spikes do not immediately lower quality.
- Memory protection stays active during warm-up.
- SessionGuard records whether the previous process ended without normal marker cleanup. This is treated as a hint only because Android may terminate apps normally.
- Optional `safeModeAfterUncleanSession` (off by default) can make AUTO choose Compatibility mode after an unclean session.
- `/ghostboost report` writes `config/ghostboost-support-report.txt` with graphics, memory, frametime, Fisk and AutoTune diagnostics.
- `/ghostboost restore` returns the current world to the baseline settings captured on entry.

## Recommended first test

1. Launch Minecraft 1.7.10 + Forge + Fisk with GhostBoost.
2. Enter the same test world/location you normally use.
3. Run `/ghostboost benchmark start 60` and play/fly/use powers normally.
4. Run `/ghostboost autotune start 60` for a second representative pass.
5. Use `/ghostboost status` and `/ghostboost report` after testing.

Do not compare only peak FPS. P95/P99 frametime and stutter rate are often more important on Android.

## Commands

- `/ghostboost status`
- `/ghostboost diagnose`
- `/ghostboost report`
- `/ghostboost restore`
- `/ghostboost profile auto|compatibility|balanced|performance`
- `/ghostboost benchmark start 60`
- `/ghostboost benchmark result`
- `/ghostboost autotune start 60`
- `/ghostboost autotune status`
- `/ghostboost autotune reset`
