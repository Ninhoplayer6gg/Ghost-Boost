package com.ghostboost.profile;

import java.util.Arrays;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;

/** Lightweight client-side frametime sampler for Android-class devices. */
public final class FrameTimeProfiler {

    public static final FrameTimeProfiler INSTANCE = new FrameTimeProfiler();
    private static final int CAPACITY = 240;
    private final long[] samples = new long[CAPACITY];
    private int size;
    private int cursor;
    private long lastFrameNanos;
    private long fpsWindowStartNanos;
    private int fpsWindowFrames;
    private int estimatedFps;

    private FrameTimeProfiler() {}

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        long now = System.nanoTime();
        if (fpsWindowStartNanos == 0L) fpsWindowStartNanos = now;
        fpsWindowFrames++;
        long fpsElapsed = now - fpsWindowStartNanos;
        if (fpsElapsed >= 1_000_000_000L) {
            estimatedFps = Math.max(1, (int) Math.round((fpsWindowFrames * 1_000_000_000D) / fpsElapsed));
            fpsWindowFrames = 0;
            fpsWindowStartNanos = now;
        }
        if (lastFrameNanos != 0L) {
            long delta = now - lastFrameNanos;
            if (delta > 0L && delta < 5_000_000_000L) {
                samples[cursor] = delta;
                cursor = (cursor + 1) % CAPACITY;
                if (size < CAPACITY) size++;
            }
        }
        lastFrameNanos = now;
    }

    public synchronized double getAverageMs() {
        if (size == 0) return 0D;
        long sum = 0L;
        for (int i = 0; i < size; i++) sum += samples[i];
        return sum / 1_000_000D / size;
    }

    public synchronized double getPercentileMs(double percentile) {
        if (size == 0) return 0D;
        long[] copy = new long[size];
        System.arraycopy(samples, 0, copy, 0, size);
        Arrays.sort(copy);
        int index = (int) Math.ceil((percentile / 100D) * size) - 1;
        if (index < 0) index = 0;
        if (index >= size) index = size - 1;
        return copy[index] / 1_000_000D;
    }

    public synchronized double getStutterRate() {
        if (size == 0) return 0D;
        int stutters = 0;
        for (int i = 0; i < size; i++) {
            if (samples[i] >= 50_000_000L) stutters++;
        }
        return (double) stutters / (double) size;
    }


    public synchronized int getEstimatedFps() {
        if (estimatedFps > 0) return estimatedFps;
        double averageMs = getAverageMs();
        if (averageMs <= 0D) return 0;
        return Math.max(1, (int) Math.round(1000D / averageMs));
    }

    public synchronized int getSampleCount() {
        return size;
    }

    public synchronized void reset() {
        java.util.Arrays.fill(samples, 0L);
        size = 0;
        cursor = 0;
        lastFrameNanos = 0L;
        fpsWindowStartNanos = 0L;
        fpsWindowFrames = 0;
        estimatedFps = 0;
    }
}
