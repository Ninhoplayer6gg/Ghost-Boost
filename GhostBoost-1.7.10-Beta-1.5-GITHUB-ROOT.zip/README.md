# GhostBoost 1.7.10 — Beta 1.5

First unified optimization build after Beta 1.0.

## Included
- Adaptive frametime + memory controller
- AutoTune and benchmark
- Android/renderer detection
- Fisk compatibility and HeroPack diagnostics
- Particle Budget
- Entity Render Budget
- Special Render Budget
- Fisk Burst Guard
- **Ghost Optimization Kernel**

The kernel combines frame pressure, heap pressure, Performance profile and heavy Fisk content into a smoothed 0–100 score. All GhostBoost render budgets use that score so optimizations become stronger together under load and recover gradually when the device stabilizes.

Compatibility profile disables aggressive budget scaling.

Target: Minecraft 1.7.10 + Forge 10.13.4.1614.
