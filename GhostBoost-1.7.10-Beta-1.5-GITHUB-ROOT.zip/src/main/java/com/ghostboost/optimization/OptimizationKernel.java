package com.ghostboost.optimization;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.compat.FiskRuntimeTuner;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.MemoryState;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;

/**
 * Unified pressure score for mobile budgets.
 *
 * It does not alter game state itself. Particle/entity/special render budgets
 * read this smoothed score so they react together instead of fighting each other.
 */
public final class OptimizationKernel {

    public static final OptimizationKernel INSTANCE = new OptimizationKernel();

    private int ticks;
    private int pressureScore;
    private int targetScore;
    private double budgetScale = 1.0D;

    private OptimizationKernel() {}

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostConfig.enabled || !GhostConfig.optimizationKernelEnabled) return;
        ticks++;
        if (ticks % 20 != 0) return;

        if (!PlatformProfile.INSTANCE.isMobileLike()) {
            targetScore = 0;
            pressureScore = 0;
            budgetScale = 1.0D;
            return;
        }

        PerformanceController perf = PerformanceController.INSTANCE;
        FrameBudgetState frame = perf.getFrameBudgetState();
        MemoryState memory = perf.getMemoryState();
        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();

        int score = 0;
        if (frame == FrameBudgetState.PRESSURED) score += 45;
        else if (frame == FrameBudgetState.SEVERE) score += 75;

        if (memory == MemoryState.WARNING) score += 12;
        else if (memory == MemoryState.CRITICAL) score += 24;
        else if (memory == MemoryState.EMERGENCY) score += 34;

        if (profile == PerformanceProfile.PERFORMANCE) score += 10;
        if (FiskCompat.isLoaded() && FiskRuntimeTuner.INSTANCE.isHeavyContent()) score += 8;

        targetScore = Math.max(0, Math.min(100, score));

        // Smooth one-second samples to prevent budget thrashing.
        if (pressureScore < targetScore) {
            pressureScore = Math.min(targetScore, pressureScore + GhostConfig.kernelRisePerSecond);
        } else if (pressureScore > targetScore) {
            pressureScore = Math.max(targetScore, pressureScore - GhostConfig.kernelRecoveryPerSecond);
        }

        if (profile == PerformanceProfile.COMPATIBILITY) {
            budgetScale = 1.0D;
        } else if (pressureScore >= 85) {
            budgetScale = 0.68D;
        } else if (pressureScore >= 65) {
            budgetScale = 0.78D;
        } else if (pressureScore >= 45) {
            budgetScale = 0.88D;
        } else {
            budgetScale = 1.0D;
        }
    }

    public int getPressureScore() { return pressureScore; }
    public int getTargetScore() { return targetScore; }
    public double getBudgetScale() { return budgetScale; }

    public int scaleDistance(int distance, int floor) {
        return Math.max(floor, (int) Math.round(distance * budgetScale));
    }
}
