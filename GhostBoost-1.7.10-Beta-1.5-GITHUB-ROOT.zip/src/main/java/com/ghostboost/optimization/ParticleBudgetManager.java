package com.ghostboost.optimization;

import java.lang.reflect.Field;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.EffectRenderer;

/**
 * Mobile particle budget for 1.7.10.
 *
 * This stage intentionally avoids bytecode patches. Under sustained pressure it
 * trims only over-budget particle lists. Compatibility profile never trims.
 */
public final class ParticleBudgetManager {

    public static final ParticleBudgetManager INSTANCE = new ParticleBudgetManager();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Particles");

    private Field fxLayersField;
    private boolean reflectionResolved;
    private boolean reflectionAvailable;
    private int ticks;
    private int activeParticles;
    private long trimmedParticles;
    private int trimPasses;
    private double externalPressureMultiplier = 1.0D;

    private ParticleBudgetManager() {}

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostConfig.enabled || !GhostConfig.particleBudgetEnabled) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.theWorld == null || mc.effectRenderer == null || mc.currentScreen != null) return;
        if (!PlatformProfile.INSTANCE.isMobileLike()) return;

        ticks++;
        if (ticks % Math.max(1, GhostConfig.particleBudgetSampleTicks) != 0) return;

        List[] layers = getLayers(mc.effectRenderer);
        if (layers == null) return;

        activeParticles = countParticles(layers);
        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();
        if (profile == PerformanceProfile.COMPATIBILITY) return;

        FrameBudgetState state = PerformanceController.INSTANCE.getFrameBudgetState();
        if (state == FrameBudgetState.HEALTHY && profile != PerformanceProfile.PERFORMANCE) return;

        int cap = computeLayerCap(state, profile);
        if (cap <= 0) return;

        int removed = 0;
        for (int i = 0; i < layers.length; i++) {
            List layer = layers[i];
            if (layer == null || layer.size() <= cap) continue;

            int remove = layer.size() - cap;
            // Oldest particles are at the front on vanilla's EffectRenderer lists.
            layer.subList(0, remove).clear();
            removed += remove;
        }

        if (removed > 0) {
            trimmedParticles += removed;
            trimPasses++;
            activeParticles = Math.max(0, activeParticles - removed);
            if (trimPasses <= 3 || trimPasses % 20 == 0) {
                LOG.info("Particle budget trimmed {} particles (active={}, cap/layer={}, state={}).",
                    removed, activeParticles, cap, state);
            }
        }
    }

    private int computeLayerCap(FrameBudgetState state, PerformanceProfile profile) {
        int cap = GhostConfig.particleSoftCap;
        if (profile == PerformanceProfile.PERFORMANCE) cap = Math.min(cap, GhostConfig.particlePerformanceCap);
        if (state == FrameBudgetState.PRESSURED) cap = Math.min(cap, GhostConfig.particlePressureCap);
        if (state == FrameBudgetState.SEVERE) cap = Math.min(cap, GhostConfig.particleSevereCap);
        cap = (int) Math.round(cap * externalPressureMultiplier * OptimizationKernel.INSTANCE.getBudgetScale());
        return Math.max(64, cap);
    }

    private List[] getLayers(EffectRenderer renderer) {
        if (!reflectionResolved) resolveField(renderer.getClass());
        if (!reflectionAvailable || fxLayersField == null) return null;
        try {
            Object value = fxLayersField.get(renderer);
            return value instanceof List[] ? (List[]) value : null;
        } catch (Throwable t) {
            reflectionAvailable = false;
            LOG.warn("Particle budget disabled: EffectRenderer particle lists became inaccessible.");
            return null;
        }
    }

    private void resolveField(Class<?> type) {
        reflectionResolved = true;
        try {
            Field[] fields = type.getDeclaredFields();
            for (Field field : fields) {
                Class<?> fieldType = field.getType();
                if (fieldType.isArray() && List.class.isAssignableFrom(fieldType.getComponentType())) {
                    field.setAccessible(true);
                    fxLayersField = field;
                    reflectionAvailable = true;
                    LOG.info("Particle budget attached to EffectRenderer particle layers via reflection.");
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        LOG.warn("Particle budget could not locate EffectRenderer particle layers; feature will stay inactive.");
    }

    private int countParticles(List[] layers) {
        int total = 0;
        for (List layer : layers) if (layer != null) total += layer.size();
        return total;
    }

    public void setExternalPressureMultiplier(double multiplier) {
        externalPressureMultiplier = Math.max(0.35D, Math.min(1.0D, multiplier));
    }

    public int getActiveParticles() { return activeParticles; }
    public long getTrimmedParticles() { return trimmedParticles; }
    public int getTrimPasses() { return trimPasses; }
    public boolean isReflectionAvailable() { return reflectionAvailable; }
    public double getExternalPressureMultiplier() { return externalPressureMultiplier; }
}
