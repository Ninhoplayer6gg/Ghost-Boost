package com.ghostboost.optimization;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;

/**
 * Skips distant living "specials" (name/special passes) while the device is
 * pressured. Player specials remain untouched for Fisk compatibility.
 */
public final class SpecialRenderBudget {

    public static final SpecialRenderBudget INSTANCE = new SpecialRenderBudget();

    private long skippedSpecialPasses;
    private int lastDistance;

    private SpecialRenderBudget() {}

    @SubscribeEvent
    public void onSpecialsPre(RenderLivingEvent.Specials.Pre event) {
        if (!GhostConfig.enabled || !GhostConfig.specialRenderBudgetEnabled) return;
        if (!PlatformProfile.INSTANCE.isMobileLike()) return;
        if (event == null || event.entity == null) return;

        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();
        if (profile == PerformanceProfile.COMPATIBILITY) return;
        if (event.entity instanceof EntityPlayer) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.renderViewEntity == null || mc.theWorld == null || mc.currentScreen != null) return;

        FrameBudgetState state = PerformanceController.INSTANCE.getFrameBudgetState();
        if (state == FrameBudgetState.HEALTHY && profile != PerformanceProfile.PERFORMANCE) return;

        int distance = GhostConfig.specialRenderDistance;
        if (profile == PerformanceProfile.PERFORMANCE) {
            distance = Math.min(distance, GhostConfig.specialPerformanceDistance);
        }
        if (state == FrameBudgetState.PRESSURED) {
            distance = Math.min(distance, GhostConfig.specialPressureDistance);
        } else if (state == FrameBudgetState.SEVERE) {
            distance = Math.min(distance, GhostConfig.specialSevereDistance);
        }
        lastDistance = OptimizationKernel.INSTANCE.scaleDistance(Math.max(20, distance), 20);

        Entity entity = event.entity;
        double dx = entity.posX - mc.renderViewEntity.posX;
        double dy = entity.posY - mc.renderViewEntity.posY;
        double dz = entity.posZ - mc.renderViewEntity.posZ;
        if (dx * dx + dy * dy + dz * dz > (double) lastDistance * (double) lastDistance) {
            event.setCanceled(true);
            skippedSpecialPasses++;
        }
    }

    public long getSkippedSpecialPasses() { return skippedSpecialPasses; }
    public int getLastDistance() { return lastDistance; }
}
