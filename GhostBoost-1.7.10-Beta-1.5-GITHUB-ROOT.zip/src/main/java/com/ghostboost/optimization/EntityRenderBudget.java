package com.ghostboost.optimization;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;

/**
 * Distance-based render culling for non-player living entities.
 * Players (including Fisk suits rendered on players) and bosses are never culled.
 */
public final class EntityRenderBudget {

    public static final EntityRenderBudget INSTANCE = new EntityRenderBudget();

    private long culledEntities;
    private int lastDistance;

    private EntityRenderBudget() {}

    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Pre event) {
        if (!GhostConfig.enabled || !GhostConfig.entityRenderBudgetEnabled) return;
        if (!PlatformProfile.INSTANCE.isMobileLike()) return;
        if (event == null || event.entity == null) return;

        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();
        if (profile == PerformanceProfile.COMPATIBILITY) return;

        Entity entity = event.entity;
        if (entity instanceof EntityPlayer || entity instanceof IBossDisplayData) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.renderViewEntity == null || mc.theWorld == null || mc.currentScreen != null) return;

        FrameBudgetState state = PerformanceController.INSTANCE.getFrameBudgetState();
        if (state == FrameBudgetState.HEALTHY && profile != PerformanceProfile.PERFORMANCE) return;

        int distance = chooseDistance(state, profile);
        lastDistance = distance;
        double dx = entity.posX - mc.renderViewEntity.posX;
        double dy = entity.posY - mc.renderViewEntity.posY;
        double dz = entity.posZ - mc.renderViewEntity.posZ;
        double distanceSq = dx * dx + dy * dy + dz * dz;

        if (distanceSq > (double) distance * (double) distance) {
            event.setCanceled(true);
            culledEntities++;
        }
    }

    private int chooseDistance(FrameBudgetState state, PerformanceProfile profile) {
        int distance = GhostConfig.entityCullDistance;
        if (profile == PerformanceProfile.PERFORMANCE) {
            distance = Math.min(distance, GhostConfig.entityPerformanceCullDistance);
        }
        if (state == FrameBudgetState.PRESSURED) {
            distance = Math.min(distance, GhostConfig.entityPressureCullDistance);
        } else if (state == FrameBudgetState.SEVERE) {
            distance = Math.min(distance, GhostConfig.entitySevereCullDistance);
        }
        return OptimizationKernel.INSTANCE.scaleDistance(Math.max(24, distance), 24);
    }

    public long getCulledEntities() { return culledEntities; }
    public int getLastDistance() { return lastDistance; }
}
