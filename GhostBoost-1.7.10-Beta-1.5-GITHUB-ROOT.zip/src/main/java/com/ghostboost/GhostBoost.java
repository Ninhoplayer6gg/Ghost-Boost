package com.ghostboost;

import com.ghostboost.compat.FiskCompat;
import com.ghostboost.config.GhostConfig;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

@Mod(
    modid = GhostBoost.MODID,
    name = GhostBoost.NAME,
    version = GhostBoost.VERSION,
    acceptedMinecraftVersions = "[1.7.10]",
    acceptableRemoteVersions = "*"
)
public final class GhostBoost {

    public static final String MODID = "ghostboost";
    public static final String NAME = "GhostBoost";
    public static final String VERSION = "1.5.0-beta";

    @SidedProxy(clientSide = "com.ghostboost.ClientProxy", serverSide = "com.ghostboost.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        GhostConfig.load(event.getSuggestedConfigurationFile());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init();
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        FiskCompat.detect();
        proxy.postInit();
    }
}
