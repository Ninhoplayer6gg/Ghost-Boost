package com.ghostboost;

import com.ghostboost.command.GhostCommand;
import com.ghostboost.profile.FrameTimeProfiler;
import com.ghostboost.profile.PerformanceController;
import com.ghostboost.profile.ProfileManager;
import com.ghostboost.profile.RendererProbe;
import com.ghostboost.session.SessionGuard;
import com.ghostboost.optimization.ParticleBudgetManager;
import com.ghostboost.optimization.EntityRenderBudget;
import com.ghostboost.optimization.SpecialRenderBudget;
import com.ghostboost.optimization.OptimizationKernel;

import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;

public final class ClientProxy extends CommonProxy {

    @Override
    public void preInit() {
        SessionGuard.INSTANCE.initialize();
    }

    @Override
    public void init() {
        FMLCommonHandler.instance().bus().register(PerformanceController.INSTANCE);
        FMLCommonHandler.instance().bus().register(FrameTimeProfiler.INSTANCE);
        FMLCommonHandler.instance().bus().register(ParticleBudgetManager.INSTANCE);
        FMLCommonHandler.instance().bus().register(OptimizationKernel.INSTANCE);
        MinecraftForge.EVENT_BUS.register(RendererProbe.INSTANCE);
        MinecraftForge.EVENT_BUS.register(EntityRenderBudget.INSTANCE);
        MinecraftForge.EVENT_BUS.register(SpecialRenderBudget.INSTANCE);
        ClientCommandHandler.instance.registerCommand(new GhostCommand());
        ProfileManager.INSTANCE.initialize();
    }
}
