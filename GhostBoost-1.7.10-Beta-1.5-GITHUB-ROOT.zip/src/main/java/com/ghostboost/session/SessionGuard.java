package com.ghostboost.session;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.ghostboost.config.GhostConfig;

/**
 * Leaves a tiny marker while GhostBoost is running. A leftover marker only means the previous
 * process did not run the normal shutdown hook; on Android that is a hint, not proof of a crash.
 */
public final class SessionGuard {

    public static final SessionGuard INSTANCE = new SessionGuard();

    private boolean initialized;
    private boolean previousUnclean;
    private File marker;

    private SessionGuard() {}

    public void initialize() {
        if (initialized) return;
        initialized = true;
        File dir = GhostConfig.getConfigDirectory();
        if (dir == null) return;
        marker = new File(dir, "ghostboost-session.lock");
        previousUnclean = marker.isFile();
        writeMarker();
        try {
            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                @Override
                public void run() {
                    clearMarker();
                }
            }, "GhostBoost-SessionGuard"));
        } catch (IllegalStateException ignored) {
            // VM is already shutting down.
        } catch (SecurityException ignored) {
            // Restricted launcher; report simply remains unavailable.
        }
    }

    private void writeMarker() {
        if (marker == null) return;
        FileWriter writer = null;
        try {
            writer = new FileWriter(marker, false);
            writer.write("GhostBoost session active\n");
            writer.write("timestamp=" + System.currentTimeMillis() + "\n");
        } catch (IOException ignored) {
        } finally {
            if (writer != null) try { writer.close(); } catch (IOException ignored) {}
        }
    }

    private void clearMarker() {
        if (marker != null && marker.exists()) marker.delete();
    }

    public boolean wasPreviousSessionUnclean() { return previousUnclean; }
}
