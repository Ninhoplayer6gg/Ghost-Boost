package com.ghostboost.android;

import java.util.Locale;
import java.util.Map;

import com.ghostboost.config.GhostConfig;

public final class PlatformProfile {

    public static final PlatformProfile INSTANCE = new PlatformProfile();

    private final String osName;
    private final String osArch;
    private final String javaVm;
    private final String launcherHint;
    private final boolean mobileLike;

    private volatile String glVendor = "unknown";
    private volatile String glRenderer = "unknown";
    private volatile String glVersion = "unknown";

    private PlatformProfile() {
        osName = System.getProperty("os.name", "unknown");
        osArch = System.getProperty("os.arch", "unknown");
        javaVm = System.getProperty("java.vm.name", "unknown");
        launcherHint = detectLauncherHint();
        mobileLike = detectMobileLike();
    }

    private String detectLauncherHint() {
        String[] keys = {
            "POJAV_RENDERER", "POJAV_NATIVEDIR", "POJAV_HOME", "AMETHYST_HOME",
            "MESA_LOADER_DRIVER_OVERRIDE", "LIBGL_ES"
        };
        try {
            for (String key : keys) {
                String value = System.getenv(key);
                if (value != null && !value.trim().isEmpty()) return key + "=" + value;
            }
            for (Map.Entry<String, String> entry : System.getenv().entrySet()) {
                String key = entry.getKey().toUpperCase(Locale.ROOT);
                if (key.contains("POJAV") || key.contains("AMETHYST")) {
                    return entry.getKey() + "=" + entry.getValue();
                }
            }
        } catch (SecurityException ignored) {
            return "restricted-env";
        }
        return "none";
    }

    private boolean detectMobileLike() {
        if (GhostConfig.forceMobileMode) return true;
        String joined = (osName + " " + osArch + " " + javaVm + " " + launcherHint + " "
            + System.getProperty("user.home", "")).toLowerCase(Locale.ROOT);
        return joined.contains("android") || joined.contains("dalvik") || joined.contains("pojav")
            || joined.contains("amethyst") || joined.contains("aarch64") || joined.contains("arm64");
    }

    public boolean isMobileLike() {
        return mobileLike || GhostConfig.forceMobileMode;
    }

    public String getOsName() { return osName; }
    public String getOsArch() { return osArch; }
    public String getJavaVm() { return javaVm; }
    public String getLauncherHint() { return launcherHint; }
    public String getGlVendor() { return glVendor; }
    public String getGlRenderer() { return glRenderer; }
    public String getGlVersion() { return glVersion; }

    public void setGlInfo(String vendor, String renderer, String version) {
        if (vendor != null) glVendor = vendor;
        if (renderer != null) glRenderer = renderer;
        if (version != null) glVersion = version;
    }

    public String shortSummary() {
        return "mobile=" + isMobileLike() + ", arch=" + osArch + ", renderer=" + glRenderer;
    }
}
