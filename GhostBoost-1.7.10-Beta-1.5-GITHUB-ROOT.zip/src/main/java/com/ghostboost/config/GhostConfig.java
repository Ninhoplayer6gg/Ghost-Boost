package com.ghostboost.config;

import java.io.File;

import net.minecraftforge.common.config.Configuration;

public final class GhostConfig {

    private static File configDirectory;

    public static boolean enabled = true;
    public static boolean forceMobileMode = false;
    public static boolean adaptiveRenderDistance = true;
    public static boolean adaptiveParticles = true;
    public static boolean adaptiveRecovery = true;
    public static boolean allowFancyGraphicsFallback = false;
    public static boolean emergencyGc = false;
    public static boolean fiskCompatibility = true;
    public static boolean fiskAdaptiveEffects = true;
    public static boolean rendererCompatibilityMode = true;
    public static boolean autoApplyLearnedProfile = true;
    public static boolean safeModeAfterUncleanSession = false;
    public static boolean particleBudgetEnabled = true;
    public static boolean entityRenderBudgetEnabled = true;
    public static boolean specialRenderBudgetEnabled = true;
    public static boolean fiskBurstGuardEnabled = true;
    public static boolean optimizationKernelEnabled = true;
    public static int targetFps = 30;
    public static int minRenderDistance = 4;
    public static int fpsSampleSeconds = 12;
    public static int recoverySeconds = 20;
    public static int recoveryFpsMargin = 8;
    public static int memoryAdjustmentCooldownSeconds = 8;
    public static int performanceRenderDistanceCap = 6;
    public static int qualityChangeCooldownSeconds = 6;
    public static int fiskHeavyPackCount = 12;
    public static int fiskHeavyPackMb = 128;
    public static int worldWarmupSeconds = 12;
    public static int particleBudgetSampleTicks = 10;
    public static int particleSoftCap = 1400;
    public static int particlePressureCap = 1000;
    public static int particleSevereCap = 650;
    public static int particlePerformanceCap = 900;
    public static int entityCullDistance = 72;
    public static int entityPressureCullDistance = 56;
    public static int entitySevereCullDistance = 40;
    public static int entityPerformanceCullDistance = 48;
    public static int specialRenderDistance = 56;
    public static int specialPressureDistance = 44;
    public static int specialSevereDistance = 32;
    public static int specialPerformanceDistance = 40;
    public static int kernelRisePerSecond = 18;
    public static int kernelRecoveryPerSecond = 8;
    public static String defaultProfile = "auto";
    public static double warningMemoryRatio = 0.80D;
    public static double criticalMemoryRatio = 0.90D;
    public static double fiskBurstPressureMultiplier = 0.88D;
    public static double fiskBurstSevereMultiplier = 0.72D;
    public static double fiskBurstHeavyPressureMultiplier = 0.75D;
    public static double fiskBurstHeavySevereMultiplier = 0.58D;

    private GhostConfig() {}

    public static void load(File file) {
        configDirectory = file == null ? null : file.getParentFile();
        Configuration cfg = new Configuration(file);
        try {
            cfg.load();
            enabled = cfg.getBoolean("enabled", "general", true,
                "Master switch for GhostBoost runtime optimizations.");
            forceMobileMode = cfg.getBoolean("forceMobileMode", "android", false,
                "Force Android/mobile tuning even when the launcher cannot be detected automatically.");
            adaptiveRenderDistance = cfg.getBoolean("adaptiveRenderDistance", "performance", true,
                "Reduce render distance one step at a time when sustained FPS is below the target.");
            adaptiveParticles = cfg.getBoolean("adaptiveParticles", "performance", true,
                "Reduce particles when heap pressure becomes critical.");
            adaptiveRecovery = cfg.getBoolean("adaptiveRecovery", "performance", true,
                "Gradually restore render distance and particles after sustained stable performance.");
            allowFancyGraphicsFallback = cfg.getBoolean("allowFancyGraphicsFallback", "performance", false,
                "Allow GhostBoost to disable Fancy Graphics during severe memory pressure.");
            emergencyGc = cfg.getBoolean("emergencyGc", "memory", false,
                "Allow a rare explicit GC during extreme heap pressure. Can cause a visible hitch.");
            fiskCompatibility = cfg.getBoolean("fiskCompatibility", "compatibility", true,
                "Enable conservative compatibility behavior when Fisk's Superheroes is present.");
            fiskAdaptiveEffects = cfg.getBoolean("fiskAdaptiveEffects", "compatibility", true,
                "Allow extra particle pressure control when Fisk is active on a mobile translation renderer.");
            rendererCompatibilityMode = cfg.getBoolean("rendererCompatibilityMode", "compatibility", true,
                "Classify translation renderers and apply conservative mobile compatibility fallbacks.");
            autoApplyLearnedProfile = cfg.getBoolean("autoApplyLearnedProfile", "profiles", true,
                "Apply a previously learned AutoTune result when the hardware/renderer/Fisk fingerprint matches.");
            safeModeAfterUncleanSession = cfg.getBoolean("safeModeAfterUncleanSession", "compatibility", false,
                "If enabled, AUTO starts in Compatibility profile after an unclean previous session. Disabled by default because Android may kill apps normally.");
            particleBudgetEnabled = cfg.getBoolean("particleBudgetEnabled", "particles", true,
                "Enable the conservative adaptive particle-list budget on mobile.");
            entityRenderBudgetEnabled = cfg.getBoolean("entityRenderBudgetEnabled", "entities", true,
                "Cull distant non-player living entity models only while the mobile renderer is under pressure.");
            specialRenderBudgetEnabled = cfg.getBoolean("specialRenderBudgetEnabled", "entities", true,
                "Skip distant non-player living special render passes while mobile frame pressure is active.");
            fiskBurstGuardEnabled = cfg.getBoolean("fiskBurstGuardEnabled", "compatibility", true,
                "Tighten only GhostBoost particle budgets during Fisk-heavy combat pressure on mobile.");
            optimizationKernelEnabled = cfg.getBoolean("optimizationKernelEnabled", "performance", true,
                "Coordinate GhostBoost render budgets with a smoothed mobile pressure score.");

            targetFps = cfg.getInt("targetFps", "performance", 30, 15, 120,
                "Target FPS used by the adaptive controller.");
            minRenderDistance = cfg.getInt("minRenderDistance", "performance", 4, 2, 16,
                "GhostBoost will never reduce render distance below this value.");
            fpsSampleSeconds = cfg.getInt("fpsSampleSeconds", "performance", 12, 4, 60,
                "How long FPS must remain low before GhostBoost reduces render distance.");
            recoverySeconds = cfg.getInt("recoverySeconds", "performance", 20, 5, 120,
                "Stable seconds required before GhostBoost restores one quality step.");
            recoveryFpsMargin = cfg.getInt("recoveryFpsMargin", "performance", 8, 2, 30,
                "FPS headroom above the target required for quality recovery.");
            memoryAdjustmentCooldownSeconds = cfg.getInt("memoryAdjustmentCooldownSeconds", "memory", 8, 2, 60,
                "Minimum seconds between destructive memory-pressure quality reductions.");
            performanceRenderDistanceCap = cfg.getInt("performanceRenderDistanceCap", "profiles", 6, 2, 16,
                "Maximum chunk render distance applied when Performance profile is selected.");
            qualityChangeCooldownSeconds = cfg.getInt("qualityChangeCooldownSeconds", "performance", 6, 2, 30,
                "Minimum seconds between adaptive quality changes to prevent oscillation.");
            fiskHeavyPackCount = cfg.getInt("fiskHeavyPackCount", "compatibility", 12, 1, 200,
                "HeroPack count considered heavy for diagnostics.");
            fiskHeavyPackMb = cfg.getInt("fiskHeavyPackMb", "compatibility", 128, 16, 4096,
                "Total Fisk HeroPack size in MB considered heavy for diagnostics.");
            worldWarmupSeconds = cfg.getInt("worldWarmupSeconds", "performance", 12, 0, 60,
                "Seconds after entering a world before FPS-based quality reductions begin. Memory protection remains active.");
            particleBudgetSampleTicks = cfg.getInt("particleBudgetSampleTicks", "particles", 10, 1, 100,
                "Client ticks between particle budget checks.");
            particleSoftCap = cfg.getInt("particleSoftCap", "particles", 1400, 64, 4000,
                "Per-layer particle cap used by balanced mobile tuning.");
            particlePressureCap = cfg.getInt("particlePressureCap", "particles", 1000, 64, 4000,
                "Per-layer particle cap while frame pressure is sustained.");
            particleSevereCap = cfg.getInt("particleSevereCap", "particles", 650, 64, 4000,
                "Per-layer particle cap during severe frame pressure.");
            particlePerformanceCap = cfg.getInt("particlePerformanceCap", "particles", 900, 64, 4000,
                "Per-layer particle cap for Performance profile.");
            entityCullDistance = cfg.getInt("entityCullDistance", "entities", 72, 24, 192,
                "Normal maximum entity render distance used only while culling is active.");
            entityPressureCullDistance = cfg.getInt("entityPressureCullDistance", "entities", 56, 24, 192,
                "Entity render distance while frame pressure is sustained.");
            entitySevereCullDistance = cfg.getInt("entitySevereCullDistance", "entities", 40, 24, 192,
                "Entity render distance during severe frame pressure.");
            entityPerformanceCullDistance = cfg.getInt("entityPerformanceCullDistance", "entities", 48, 24, 192,
                "Entity render distance in Performance profile.");
            specialRenderDistance = cfg.getInt("specialRenderDistance", "entities", 56, 20, 192,
                "Normal distance used for special render pass culling while active.");
            specialPressureDistance = cfg.getInt("specialPressureDistance", "entities", 44, 20, 192,
                "Special render distance while frame pressure is sustained.");
            specialSevereDistance = cfg.getInt("specialSevereDistance", "entities", 32, 20, 192,
                "Special render distance during severe frame pressure.");
            specialPerformanceDistance = cfg.getInt("specialPerformanceDistance", "entities", 40, 20, 192,
                "Special render distance in Performance profile.");
            kernelRisePerSecond = cfg.getInt("kernelRisePerSecond", "performance", 18, 1, 100,
                "Maximum pressure-score increase per second.");
            kernelRecoveryPerSecond = cfg.getInt("kernelRecoveryPerSecond", "performance", 8, 1, 100,
                "Maximum pressure-score recovery per second.");

            defaultProfile = cfg.getString("defaultProfile", "profiles", "auto",
                "Default session profile: auto, compatibility, balanced or performance.");
            warningMemoryRatio = cfg.getFloat("warningMemoryRatio", "memory", 0.80F, 0.50F, 0.98F,
                "Heap usage ratio that begins warning/monitoring behavior.");
            criticalMemoryRatio = cfg.getFloat("criticalMemoryRatio", "memory", 0.90F, 0.60F, 0.99F,
                "Heap usage ratio that allows emergency performance fallbacks.");
            fiskBurstPressureMultiplier = cfg.getFloat("fiskBurstPressureMultiplier", "compatibility", 0.88F, 0.35F, 1.0F,
                "Particle-budget multiplier for Fisk during pressured frames.");
            fiskBurstSevereMultiplier = cfg.getFloat("fiskBurstSevereMultiplier", "compatibility", 0.72F, 0.35F, 1.0F,
                "Particle-budget multiplier for Fisk during severe frame pressure.");
            fiskBurstHeavyPressureMultiplier = cfg.getFloat("fiskBurstHeavyPressureMultiplier", "compatibility", 0.75F, 0.35F, 1.0F,
                "Particle-budget multiplier when Fisk HeroPack content is heavy and frames are pressured.");
            fiskBurstHeavySevereMultiplier = cfg.getFloat("fiskBurstHeavySevereMultiplier", "compatibility", 0.58F, 0.35F, 1.0F,
                "Particle-budget multiplier when Fisk HeroPack content is heavy and frame pressure is severe.");
        } finally {
            if (cfg.hasChanged()) cfg.save();
        }
    }

    public static File getConfigDirectory() {
        return configDirectory;
    }
}
