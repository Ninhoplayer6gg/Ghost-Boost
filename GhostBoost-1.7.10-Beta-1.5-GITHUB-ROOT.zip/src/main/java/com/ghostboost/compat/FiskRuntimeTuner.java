package com.ghostboost.compat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.FrameBudgetState;
import com.ghostboost.profile.PerformanceProfile;
import com.ghostboost.profile.ProfileManager;
import com.ghostboost.optimization.ParticleBudgetManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** Conservative runtime tuning for Fisk on mobile translation renderers. */
public final class FiskRuntimeTuner {

    public static final FiskRuntimeTuner INSTANCE = new FiskRuntimeTuner();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Fisk");

    private int changes;
    private FrameBudgetState lastState = FrameBudgetState.HEALTHY;
    private double particleMultiplier = 1.0D;
    private boolean heavyContent;

    private FiskRuntimeTuner() {}

    public void onRendererReady() {
        FiskContentProfile.INSTANCE.refresh();
    }

    public void onSample(FrameBudgetState state) {
        lastState = state == null ? FrameBudgetState.HEALTHY : state;
        if (!GhostConfig.fiskCompatibility || !GhostConfig.fiskAdaptiveEffects || !FiskCompat.isLoaded()) return;
        if (!PlatformProfile.INSTANCE.isMobileLike()) return;
        RendererType renderer = CompatibilityEngine.INSTANCE.getRendererType();
        if (!isTranslationLayer(renderer)) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null || mc.theWorld == null) return;
        GameSettings settings = mc.gameSettings;
        PerformanceProfile profile = ProfileManager.INSTANCE.getEffective();
        FiskContentProfile content = FiskContentProfile.INSTANCE;
        heavyContent = content.getPackCount() >= GhostConfig.fiskHeavyPackCount
            || content.getTotalMb() >= GhostConfig.fiskHeavyPackMb;

        updateParticleBurstBudget(profile);

        if (lastState == FrameBudgetState.SEVERE && settings.particleSetting < 1) {
            settings.particleSetting = 1;
            changes++;
            LOG.info("Fisk mobile guard reduced particles during severe frame pressure.");
        }
        if (profile == PerformanceProfile.PERFORMANCE && settings.advancedOpengl) {
            settings.advancedOpengl = false;
            changes++;
        }
    }


    private void updateParticleBurstBudget(PerformanceProfile profile) {
        double next = 1.0D;
        if (GhostConfig.fiskBurstGuardEnabled && profile != PerformanceProfile.COMPATIBILITY) {
            if (lastState == FrameBudgetState.SEVERE) {
                next = heavyContent ? GhostConfig.fiskBurstHeavySevereMultiplier
                    : GhostConfig.fiskBurstSevereMultiplier;
            } else if (lastState == FrameBudgetState.PRESSURED) {
                next = heavyContent ? GhostConfig.fiskBurstHeavyPressureMultiplier
                    : GhostConfig.fiskBurstPressureMultiplier;
            }
        }

        if (Math.abs(next - particleMultiplier) > 0.001D) {
            particleMultiplier = next;
            ParticleBudgetManager.INSTANCE.setExternalPressureMultiplier(next);
            changes++;
            LOG.info("Fisk burst guard particle budget multiplier -> {} (heavyContent={}, state={}).",
                particleMultiplier, heavyContent, lastState);
        }
    }

    private boolean isTranslationLayer(RendererType type) {
        return type == RendererType.MOBILEGLUES || type == RendererType.ZINK || type == RendererType.VIRGL
            || type == RendererType.GL4ES || type == RendererType.ANGLE || type == RendererType.SOFTWARE;
    }

    public int getChanges() { return changes; }
    public FrameBudgetState getLastState() { return lastState; }
    public double getParticleMultiplier() { return particleMultiplier; }
    public boolean isHeavyContent() { return heavyContent; }
}
