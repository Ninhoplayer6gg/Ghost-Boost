package com.ghostboost.compat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.profile.ProfileManager;
import com.ghostboost.profile.AutoTuneManager;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** Conservative compatibility rules. No Fisk classes are patched directly in this stage. */
public final class CompatibilityEngine {

    public static final CompatibilityEngine INSTANCE = new CompatibilityEngine();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Compatibility");

    private RendererType rendererType = RendererType.NATIVE_OR_UNKNOWN;
    private String summary = "not evaluated";

    private CompatibilityEngine() {}

    public void evaluateAndApply() {
        rendererType = RendererClassifier.classify();
        ProfileManager.INSTANCE.onRendererReady();
        FiskRuntimeTuner.INSTANCE.onRendererReady();
        AutoTuneManager.INSTANCE.onRendererReady();
        boolean mobile = PlatformProfile.INSTANCE.isMobileLike();
        boolean fisk = FiskCompat.isLoaded();

        if (!GhostConfig.rendererCompatibilityMode) {
            summary = "compatibility rules disabled";
            return;
        }

        if (!mobile) {
            summary = "desktop-like environment; no mobile fallback applied";
            return;
        }

        if (fisk && GhostConfig.fiskCompatibility && isTranslationLayer(rendererType)) {
            GameSettings settings = Minecraft.getMinecraft().gameSettings;
            if (settings != null && settings.advancedOpengl) {
                settings.advancedOpengl = false;
                LOG.info("Compatibility engine disabled Advanced OpenGL for Fisk on {}.", rendererType);
            }
            summary = "Fisk safe path active on " + rendererType;
            return;
        }

        if (rendererType == RendererType.SOFTWARE) {
            summary = "software renderer detected; performance profile recommended";
            return;
        }

        summary = "no extra fallback required for " + rendererType;
    }

    private boolean isTranslationLayer(RendererType type) {
        return type == RendererType.MOBILEGLUES || type == RendererType.ZINK || type == RendererType.VIRGL
            || type == RendererType.GL4ES || type == RendererType.ANGLE;
    }

    public RendererType getRendererType() {
        return rendererType;
    }

    public String getSummary() {
        return summary;
    }
}
