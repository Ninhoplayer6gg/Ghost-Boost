package com.ghostboost.compat;

import java.io.File;

import net.minecraft.client.Minecraft;

/** Lightweight scan of Fisk's HeroPack directory. No archives are opened or modified. */
public final class FiskContentProfile {

    public static final FiskContentProfile INSTANCE = new FiskContentProfile();

    private int packCount;
    private long totalBytes;
    private long largestBytes;
    private String largestName = "none";
    private File detectedDirectory;

    private FiskContentProfile() {}

    public void refresh() {
        packCount = 0;
        totalBytes = 0L;
        largestBytes = 0L;
        largestName = "none";
        detectedDirectory = null;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.mcDataDir == null || !FiskCompat.isLoaded()) return;

        File[] candidates = {
            new File(mc.mcDataDir, "fiskheroes"),
            new File(mc.mcDataDir, "heropacks"),
            new File(new File(mc.mcDataDir, "config"), "fiskheroes")
        };
        for (File dir : candidates) {
            if (dir.isDirectory()) {
                detectedDirectory = dir;
                scanImmediate(dir);
                return;
            }
        }
    }

    private void scanImmediate(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file == null || file.isHidden()) continue;
            String name = file.getName().toLowerCase(java.util.Locale.ROOT);
            if (file.isDirectory() || name.endsWith(".zip") || name.endsWith(".jar")) {
                long size = file.isDirectory() ? directorySize(file, 2) : file.length();
                packCount++;
                totalBytes += Math.max(0L, size);
                if (size > largestBytes) {
                    largestBytes = size;
                    largestName = file.getName();
                }
            }
        }
    }

    private long directorySize(File dir, int depth) {
        if (depth < 0 || dir == null || !dir.isDirectory()) return 0L;
        File[] files = dir.listFiles();
        if (files == null) return 0L;
        long total = 0L;
        for (File file : files) {
            if (file == null || file.isHidden()) continue;
            total += file.isDirectory() ? directorySize(file, depth - 1) : Math.max(0L, file.length());
        }
        return total;
    }

    public int getPackCount() { return packCount; }
    public long getTotalBytes() { return totalBytes; }
    public long getLargestBytes() { return largestBytes; }
    public String getLargestName() { return largestName; }
    public String getDirectoryName() { return detectedDirectory == null ? "not-found" : detectedDirectory.getAbsolutePath(); }
    public long getTotalMb() { return totalBytes / (1024L * 1024L); }
    public long getLargestMb() { return largestBytes / (1024L * 1024L); }
}
