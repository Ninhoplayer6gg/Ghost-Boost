package com.ghostboost.compat;

import java.util.Locale;

import com.ghostboost.android.PlatformProfile;

public final class RendererClassifier {

    private RendererClassifier() {}

    public static RendererType classify() {
        PlatformProfile p = PlatformProfile.INSTANCE;
        String text = (p.getGlVendor() + " " + p.getGlRenderer() + " " + p.getGlVersion() + " "
            + p.getLauncherHint() + " " + env("POJAV_RENDERER") + " " + env("MESA_LOADER_DRIVER_OVERRIDE"))
            .toLowerCase(Locale.ROOT);

        if (text.contains("mobileglues") || text.contains("mobileglue")) return RendererType.MOBILEGLUES;
        if (text.contains("zink")) return RendererType.ZINK;
        if (text.contains("virgl")) return RendererType.VIRGL;
        if (text.contains("gl4es")) return RendererType.GL4ES;
        if (text.contains("angle")) return RendererType.ANGLE;
        if (text.contains("llvmpipe") || text.contains("softpipe") || text.contains("swiftshader")) return RendererType.SOFTWARE;
        return RendererType.NATIVE_OR_UNKNOWN;
    }

    private static String env(String key) {
        try {
            String value = System.getenv(key);
            return value == null ? "" : value;
        } catch (SecurityException ignored) {
            return "";
        }
    }
}
