package com.ghostboost.compat;

import java.util.Locale;

import cpw.mods.fml.common.Loader;
import cpw.mods.fml.common.ModContainer;

public final class FiskCompat {

    private static volatile boolean loaded;
    private static volatile String detectedId = "not-found";
    private static volatile String detectedVersion = "unknown";

    private FiskCompat() {}

    public static void detect() {
        loaded = false;
        for (ModContainer mod : Loader.instance().getActiveModList()) {
            String id = safe(mod.getModId()).toLowerCase(Locale.ROOT);
            String name = safe(mod.getName()).toLowerCase(Locale.ROOT);
            if (id.contains("fiskhero") || name.contains("fisk") && name.contains("superhero")) {
                loaded = true;
                detectedId = mod.getModId();
                detectedVersion = safe(mod.getVersion());
                return;
            }
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    public static boolean isLoaded() { return loaded; }
    public static String getDetectedId() { return detectedId; }
    public static String getDetectedVersion() { return detectedVersion; }
}
