package com.ghostboost.compat;

public enum RendererType {
    MOBILEGLUES,
    ZINK,
    VIRGL,
    GL4ES,
    ANGLE,
    SOFTWARE,
    NATIVE_OR_UNKNOWN
}
