package com.ghostboost.profile;

public enum FrameBudgetState {
    HEALTHY,
    PRESSURED,
    SEVERE
}
