package com.ghostboost.profile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.compat.FiskRuntimeTuner;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

public final class PerformanceController {

    public static final PerformanceController INSTANCE = new PerformanceController();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Performance");

    private int ticks;
    private int worldSampleAge;
    private int lowFpsSamples;
    private int stableFpsSamples;
    private int lastFps;
    private double lastMemoryRatio;
    private int adjustments;
    private long lastEmergencyGc;
    private long lastMemoryAdjustment;
    private long lastQualityAdjustment;
    private MemoryState memoryState = MemoryState.NORMAL;
    private FrameBudgetState frameBudgetState = FrameBudgetState.HEALTHY;
    private Object worldMarker;
    private int baselineRenderDistance = -1;
    private int baselineParticles = -1;
    private boolean baselineFancyGraphics;

    private PerformanceController() {}

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !GhostConfig.enabled) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;

        if (mc.theWorld != worldMarker) {
            worldMarker = mc.theWorld;
            lowFpsSamples = 0;
            stableFpsSamples = 0;
            worldSampleAge = 0;
            if (worldMarker != null) {
                baselineRenderDistance = mc.gameSettings.renderDistanceChunks;
                baselineParticles = mc.gameSettings.particleSetting;
                baselineFancyGraphics = mc.gameSettings.fancyGraphics;
                LOG.info("Adaptive baseline captured: {} chunks, particle level {}.",
                    baselineRenderDistance, baselineParticles);
            }
        }

        ticks++;
        if (ticks % 20 != 0) return;

        lastFps = Minecraft.getDebugFPS();
        Runtime runtime = Runtime.getRuntime();
        long max = runtime.maxMemory();
        long used = runtime.totalMemory() - runtime.freeMemory();
        lastMemoryRatio = max <= 0L ? 0D : (double) used / (double) max;
        updateMemoryState();
        frameBudgetState = FrameBudgetAnalyzer.INSTANCE.evaluate(lastFps);
        FiskRuntimeTuner.INSTANCE.onSample(frameBudgetState);
        AutoTuneManager.INSTANCE.sample(lastFps, lastMemoryRatio, frameBudgetState);
        BenchmarkManager.INSTANCE.sample(lastFps, lastMemoryRatio,
            FrameTimeProfiler.INSTANCE.getAverageMs(), FrameTimeProfiler.INSTANCE.getPercentileMs(95D));

        if (!PlatformProfile.INSTANCE.isMobileLike() || mc.theWorld == null || mc.currentScreen != null) return;

        worldSampleAge++;
        if (worldSampleAge > GhostConfig.worldWarmupSeconds) handleFps(mc.gameSettings);
        handleMemory(mc.gameSettings);
    }

    private void handleFps(GameSettings settings) {
        if (!GhostConfig.adaptiveRenderDistance || lastFps <= 0) return;

        boolean struggling = frameBudgetState != FrameBudgetState.HEALTHY;
        boolean stable = frameBudgetState == FrameBudgetState.HEALTHY
            && lastFps >= GhostConfig.targetFps + GhostConfig.recoveryFpsMargin
            && lastMemoryRatio < GhostConfig.warningMemoryRatio;

        if (struggling) {
            lowFpsSamples += frameBudgetState == FrameBudgetState.SEVERE ? 2 : 1;
            stableFpsSamples = 0;
        } else if (stable) {
            stableFpsSamples++;
            lowFpsSamples = Math.max(0, lowFpsSamples - 2);
        } else {
            lowFpsSamples = Math.max(0, lowFpsSamples - 1);
            stableFpsSamples = Math.max(0, stableFpsSamples - 1);
        }

        if (lowFpsSamples >= GhostConfig.fpsSampleSeconds && canAdjustQuality()) {
            int step = frameBudgetState == FrameBudgetState.SEVERE ? 2 : 1;
            int next = Math.max(GhostConfig.minRenderDistance, settings.renderDistanceChunks - step);
            if (next < settings.renderDistanceChunks) {
                settings.renderDistanceChunks = next;
                markQualityAdjustment();
                LOG.info("Frame budget {}: render distance reduced to {} chunks (FPS {}, P95 {} ms, P99 {} ms).",
                    frameBudgetState, settings.renderDistanceChunks, lastFps,
                    Math.round(FrameTimeProfiler.INSTANCE.getPercentileMs(95D)),
                    Math.round(FrameTimeProfiler.INSTANCE.getPercentileMs(99D)));
            }
            if (frameBudgetState == FrameBudgetState.SEVERE && GhostConfig.adaptiveParticles && settings.particleSetting < 1) {
                settings.particleSetting = 1;
                markQualityAdjustment();
                LOG.info("Severe frame pressure: particle level reduced to {}.", settings.particleSetting);
            }
            lowFpsSamples = 0;
        }

        if (GhostConfig.adaptiveRecovery && stableFpsSamples >= GhostConfig.recoverySeconds && canAdjustQuality()) {
            if (baselineRenderDistance > 0 && settings.renderDistanceChunks < baselineRenderDistance) {
                settings.renderDistanceChunks++;
                markQualityAdjustment();
                LOG.info("Adaptive recovery: render distance restored to {} chunks.", settings.renderDistanceChunks);
            } else if (baselineParticles >= 0 && settings.particleSetting > baselineParticles) {
                settings.particleSetting--;
                markQualityAdjustment();
                LOG.info("Adaptive recovery: particle level restored to {}.", settings.particleSetting);
            }
            stableFpsSamples = 0;
        }
    }

    private boolean canAdjustQuality() {
        return System.currentTimeMillis() - lastQualityAdjustment >= GhostConfig.qualityChangeCooldownSeconds * 1000L;
    }

    private void markQualityAdjustment() {
        lastQualityAdjustment = System.currentTimeMillis();
        adjustments++;
    }

    private void updateMemoryState() {
        if (lastMemoryRatio >= 0.95D) memoryState = MemoryState.EMERGENCY;
        else if (lastMemoryRatio >= GhostConfig.criticalMemoryRatio) memoryState = MemoryState.CRITICAL;
        else if (lastMemoryRatio >= GhostConfig.warningMemoryRatio) memoryState = MemoryState.WARNING;
        else memoryState = MemoryState.NORMAL;
    }

    private void handleMemory(GameSettings settings) {
        if (lastMemoryRatio < GhostConfig.warningMemoryRatio) return;

        if (lastMemoryRatio >= GhostConfig.criticalMemoryRatio) {
            long now = System.currentTimeMillis();
            if (now - lastMemoryAdjustment < GhostConfig.memoryAdjustmentCooldownSeconds * 1000L) return;
            lastMemoryAdjustment = now;
            if (GhostConfig.adaptiveParticles && settings.particleSetting < 2) {
                settings.particleSetting++;
                markQualityAdjustment();
                LOG.info("Memory guard: particle level reduced. Heap pressure={}%.",
                    Math.round(lastMemoryRatio * 100D));
            }
            if (settings.renderDistanceChunks > GhostConfig.minRenderDistance) {
                settings.renderDistanceChunks--;
                markQualityAdjustment();
                LOG.info("Memory guard: render distance reduced to {} chunks.", settings.renderDistanceChunks);
            }
            if (GhostConfig.allowFancyGraphicsFallback && settings.fancyGraphics) {
                settings.fancyGraphics = false;
                markQualityAdjustment();
                LOG.info("Memory guard: Fancy Graphics disabled for this session.");
            }
            maybeEmergencyGc();
        }
    }

    private void maybeEmergencyGc() {
        if (!GhostConfig.emergencyGc || lastMemoryRatio < 0.95D) return;
        long now = System.currentTimeMillis();
        if (now - lastEmergencyGc < 60000L) return;
        lastEmergencyGc = now;
        System.gc();
        LOG.warn("Emergency heap guard requested a GC at {}% heap usage.",
            Math.round(lastMemoryRatio * 100D));
    }

    public void restoreBaseline() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;
        if (baselineRenderDistance > 0) mc.gameSettings.renderDistanceChunks = baselineRenderDistance;
        if (baselineParticles >= 0) mc.gameSettings.particleSetting = baselineParticles;
        mc.gameSettings.fancyGraphics = baselineFancyGraphics;
        lowFpsSamples = 0;
        stableFpsSamples = 0;
    }

    public int getLastFps() { return lastFps; }
    public int getAdjustments() { return adjustments; }
    public double getLastMemoryRatio() { return lastMemoryRatio; }
    public int getBaselineRenderDistance() { return baselineRenderDistance; }
    public MemoryState getMemoryState() { return memoryState; }
    public FrameBudgetState getFrameBudgetState() { return frameBudgetState; }
    public int getWorldSampleAge() { return worldSampleAge; }
}
