package com.ghostboost.profile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.ghostboost.GhostBoost;
import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.compat.FiskContentProfile;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.session.SessionGuard;

/** Writes a small support report containing only runtime/graphics/mod diagnostics. */
public final class SupportReport {

    private SupportReport() {}

    public static File write() {
        File dir = GhostConfig.getConfigDirectory();
        if (dir == null) return null;
        File out = new File(dir, "ghostboost-support-report.txt");
        FileWriter writer = null;
        try {
            writer = new FileWriter(out, false);
            PlatformProfile p = PlatformProfile.INSTANCE;
            PerformanceController perf = PerformanceController.INSTANCE;
            FiskContentProfile content = FiskContentProfile.INSTANCE;
            writer.write("GhostBoost support report\n");
            writer.write("version=" + GhostBoost.VERSION + "\n");
            writer.write("mobileLike=" + p.isMobileLike() + "\n");
            writer.write("os=" + p.getOsName() + "\n");
            writer.write("arch=" + p.getOsArch() + "\n");
            writer.write("javaVm=" + p.getJavaVm() + "\n");
            writer.write("launcherHint=" + p.getLauncherHint() + "\n");
            writer.write("glVendor=" + p.getGlVendor() + "\n");
            writer.write("glRenderer=" + p.getGlRenderer() + "\n");
            writer.write("glVersion=" + p.getGlVersion() + "\n");
            writer.write("rendererPath=" + CompatibilityEngine.INSTANCE.getRendererType() + "\n");
            writer.write("profile=" + ProfileManager.INSTANCE.getEffective() + "\n");
            writer.write("fps=" + perf.getLastFps() + "\n");
            writer.write("frameBudget=" + perf.getFrameBudgetState() + "\n");
            writer.write("p95Ms=" + FrameTimeProfiler.INSTANCE.getPercentileMs(95D) + "\n");
            writer.write("p99Ms=" + FrameTimeProfiler.INSTANCE.getPercentileMs(99D) + "\n");
            writer.write("stutterRate=" + FrameTimeProfiler.INSTANCE.getStutterRate() + "\n");
            writer.write("heapRatio=" + perf.getLastMemoryRatio() + "\n");
            writer.write("memoryState=" + perf.getMemoryState() + "\n");
            writer.write("fiskLoaded=" + FiskCompat.isLoaded() + "\n");
            writer.write("fiskVersion=" + FiskCompat.getDetectedVersion() + "\n");
            writer.write("heroPacks=" + content.getPackCount() + "\n");
            writer.write("heroPacksMb=" + content.getTotalMb() + "\n");
            writer.write("previousSessionUnclean=" + SessionGuard.INSTANCE.wasPreviousSessionUnclean() + "\n");
            writer.write("autotune=" + AutoTuneManager.INSTANCE.getLastSummary() + "\n");
            writer.write("\nRecommendations:\n");
            List<String> recommendations = DiagnosticEngine.buildRecommendations();
            for (String line : recommendations) writer.write("- " + line + "\n");
            return out;
        } catch (IOException ignored) {
            return null;
        } finally {
            if (writer != null) try { writer.close(); } catch (IOException ignored) {}
        }
    }
}
