package com.ghostboost.profile;

public enum PerformanceProfile {
    AUTO,
    COMPATIBILITY,
    BALANCED,
    PERFORMANCE;

    public static PerformanceProfile fromString(String value) {
        if (value == null) return AUTO;
        String normalized = value.trim().toUpperCase(java.util.Locale.ROOT);
        try {
            return PerformanceProfile.valueOf(normalized);
        } catch (IllegalArgumentException ignored) {
            return AUTO;
        }
    }
}
