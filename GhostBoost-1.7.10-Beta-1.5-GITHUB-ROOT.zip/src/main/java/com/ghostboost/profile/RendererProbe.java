package com.ghostboost.profile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL11;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.config.GhostConfig;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public final class RendererProbe {

    public static final RendererProbe INSTANCE = new RendererProbe();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Renderer");
    private boolean probed;

    private RendererProbe() {}

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (probed || !GhostConfig.enabled) return;
        probed = true;

        String vendor = GL11.glGetString(GL11.GL_VENDOR);
        String renderer = GL11.glGetString(GL11.GL_RENDERER);
        String version = GL11.glGetString(GL11.GL_VERSION);
        PlatformProfile.INSTANCE.setGlInfo(vendor, renderer, version);

        LOG.info("GhostBoost GPU probe: vendor='{}', renderer='{}', version='{}'", vendor, renderer, version);
        LOG.info("GhostBoost platform: {}", PlatformProfile.INSTANCE.shortSummary());
        CompatibilityEngine.INSTANCE.evaluateAndApply();
        LOG.info("GhostBoost compatibility: {}", CompatibilityEngine.INSTANCE.getSummary());
    }
}
