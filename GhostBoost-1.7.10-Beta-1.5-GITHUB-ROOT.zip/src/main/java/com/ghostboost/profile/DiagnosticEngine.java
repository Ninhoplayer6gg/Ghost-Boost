package com.ghostboost.profile;

import java.util.ArrayList;
import java.util.List;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.compat.FiskContentProfile;
import com.ghostboost.compat.RendererType;
import com.ghostboost.session.SessionGuard;

public final class DiagnosticEngine {

    private DiagnosticEngine() {}

    public static List<String> buildRecommendations() {
        List<String> lines = new ArrayList<String>();
        RendererType renderer = CompatibilityEngine.INSTANCE.getRendererType();
        PerformanceController perf = PerformanceController.INSTANCE;

        lines.add("Renderer: " + renderer + " | GPU: " + PlatformProfile.INSTANCE.getGlRenderer());
        lines.add("Profile: " + ProfileManager.INSTANCE.getEffective() + " | Memory: " + perf.getMemoryState()
            + " | Frame budget: " + perf.getFrameBudgetState());

        if (SessionGuard.INSTANCE.wasPreviousSessionUnclean()) {
            lines.add("Previous session ended without the normal shutdown marker cleanup. On Android this may be a crash or a normal process kill.");
        }
        if (renderer == RendererType.SOFTWARE) {
            lines.add("Software renderer detected: use Performance profile and try another renderer in the launcher.");
        }
        if (FiskCompat.isLoaded() && renderer != RendererType.NATIVE_OR_UNKNOWN) {
            lines.add("Fisk + translation renderer detected: compatibility safe path is active/relevant.");
        }
        if (FiskCompat.isLoaded()) {
            FiskContentProfile content = FiskContentProfile.INSTANCE;
            if (content.getPackCount() >= com.ghostboost.config.GhostConfig.fiskHeavyPackCount
                || content.getTotalMb() >= com.ghostboost.config.GhostConfig.fiskHeavyPackMb) {
                lines.add("Heavy HeroPack set detected: " + content.getPackCount() + " packs / " + content.getTotalMb()
                    + " MB. This can increase texture/resource pressure on mobile.");
            }
        }
        if (perf.getMemoryState() == MemoryState.CRITICAL || perf.getMemoryState() == MemoryState.EMERGENCY) {
            lines.add("Heap pressure is high: lower allocated Java heap only if Android itself is starving, otherwise reduce chunks/mod load.");
        }
        if (perf.getFrameBudgetState() == FrameBudgetState.SEVERE) {
            lines.add("Frame budget is SEVERE: GhostBoost will use larger quality steps until frametime stabilizes.");
        }
        if (FrameTimeProfiler.INSTANCE.getPercentileMs(95D) > 50D) {
            lines.add("P95 frametime exceeds 50 ms: frame spikes are a bigger problem than the average FPS.");
        }
        if (lines.size() == 2) {
            lines.add("No major GhostBoost warning detected in the current session.");
        }
        return lines;
    }
}
