package com.ghostboost.profile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.config.GhostConfig;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** Learns a stable mobile quality point for the current GPU/renderer/Fisk combination. */
public final class AutoTuneManager {

    public static final AutoTuneManager INSTANCE = new AutoTuneManager();

    private boolean running;
    private int targetSeconds;
    private int samples;
    private long fpsSum;
    private int severeSamples;
    private double maxHeap;
    private String lastSummary = "AutoTune has not run yet.";
    private boolean learnedProfileApplied;

    private AutoTuneManager() {}

    public void onRendererReady() {
        if (!GhostConfig.autoApplyLearnedProfile) return;
        Properties props = load();
        if (props == null) return;
        String fingerprint = fingerprint();
        if (!fingerprint.equals(props.getProperty("fingerprint", ""))) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;
        if (ProfileManager.INSTANCE.getRequested() != PerformanceProfile.AUTO) return;
        try {
            int chunks = Integer.parseInt(props.getProperty("renderDistance", "-1"));
            int particles = Integer.parseInt(props.getProperty("particles", "-1"));
            if (chunks >= GhostConfig.minRenderDistance && chunks <= 16) {
                mc.gameSettings.renderDistanceChunks = chunks;
            }
            if (particles >= 0 && particles <= 2) {
                mc.gameSettings.particleSetting = particles;
            }
            learnedProfileApplied = true;
            lastSummary = "Applied learned profile: " + chunks + " chunks, particle level " + particles + ".";
        } catch (NumberFormatException ignored) {
            // Corrupt/stale profile: ignore safely.
        }
    }

    public void start(int seconds) {
        targetSeconds = Math.max(30, Math.min(180, seconds));
        samples = 0;
        fpsSum = 0L;
        severeSamples = 0;
        maxHeap = 0D;
        running = true;
        lastSummary = "AutoTune running for " + targetSeconds + " seconds.";
    }

    public void sample(int fps, double heapRatio, FrameBudgetState state) {
        if (!running || fps <= 0) return;
        samples++;
        fpsSum += fps;
        if (state == FrameBudgetState.SEVERE) severeSamples++;
        maxHeap = Math.max(maxHeap, heapRatio);
        if (samples >= targetSeconds) finish();
    }

    private void finish() {
        running = false;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null || samples == 0) {
            lastSummary = "AutoTune stopped without enough game data.";
            return;
        }
        double avgFps = (double) fpsSum / (double) samples;
        double severeRatio = (double) severeSamples / (double) samples;
        boolean stable = avgFps >= GhostConfig.targetFps * 0.90D
            && severeRatio <= 0.20D
            && maxHeap < GhostConfig.criticalMemoryRatio;

        GameSettings settings = mc.gameSettings;
        if (stable && save(settings.renderDistanceChunks, settings.particleSetting)) {
            lastSummary = "AutoTune learned " + settings.renderDistanceChunks + " chunks / particle level "
                + settings.particleSetting + " (avg " + Math.round(avgFps) + " FPS, severe "
                + Math.round(severeRatio * 100D) + "%).";
        } else {
            lastSummary = "AutoTune did not save a profile: avg " + Math.round(avgFps) + " FPS, severe "
                + Math.round(severeRatio * 100D) + "%, peak heap " + Math.round(maxHeap * 100D)
                + "%. Let GhostBoost reduce load further and run AutoTune again.";
        }
    }

    private boolean save(int chunks, int particles) {
        File file = file();
        if (file == null) return false;
        Properties props = new Properties();
        props.setProperty("fingerprint", fingerprint());
        props.setProperty("renderDistance", Integer.toString(chunks));
        props.setProperty("particles", Integer.toString(particles));
        props.setProperty("targetFps", Integer.toString(GhostConfig.targetFps));
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(file, false);
            props.store(out, "GhostBoost learned mobile profile");
            return true;
        } catch (IOException ignored) {
            return false;
        } finally {
            if (out != null) try { out.close(); } catch (IOException ignored) {}
        }
    }

    private Properties load() {
        File file = file();
        if (file == null || !file.isFile()) return null;
        FileInputStream in = null;
        try {
            Properties props = new Properties();
            in = new FileInputStream(file);
            props.load(in);
            return props;
        } catch (IOException ignored) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignored) {}
        }
    }

    public boolean reset() {
        File file = file();
        learnedProfileApplied = false;
        lastSummary = "Learned profile reset.";
        return file == null || !file.exists() || file.delete();
    }

    private File file() {
        File dir = GhostConfig.getConfigDirectory();
        return dir == null ? null : new File(dir, "ghostboost-autotune.properties");
    }

    private String fingerprint() {
        String raw = PlatformProfile.INSTANCE.getOsArch() + "|" + PlatformProfile.INSTANCE.getGlVendor() + "|"
            + PlatformProfile.INSTANCE.getGlRenderer() + "|" + CompatibilityEngine.INSTANCE.getRendererType() + "|"
            + (FiskCompat.isLoaded() ? FiskCompat.getDetectedVersion() : "no-fisk");
        return Integer.toHexString(raw.hashCode()) + "-" + Integer.toHexString(raw.length());
    }

    public boolean isRunning() { return running; }
    public int getSamples() { return samples; }
    public int getTargetSeconds() { return targetSeconds; }
    public String getLastSummary() { return lastSummary; }
    public boolean wasLearnedProfileApplied() { return learnedProfileApplied; }
}
