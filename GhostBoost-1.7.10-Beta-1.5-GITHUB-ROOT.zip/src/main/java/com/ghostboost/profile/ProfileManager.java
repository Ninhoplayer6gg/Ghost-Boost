package com.ghostboost.profile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.compat.RendererType;
import com.ghostboost.config.GhostConfig;
import com.ghostboost.session.SessionGuard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** User-facing session profiles. AUTO delegates to the compatibility/performance detectors. */
public final class ProfileManager {

    public static final ProfileManager INSTANCE = new ProfileManager();
    private static final Logger LOG = LogManager.getLogger("GhostBoost/Profile");

    private PerformanceProfile requested = PerformanceProfile.AUTO;
    private PerformanceProfile effective = PerformanceProfile.AUTO;

    private ProfileManager() {}

    public void initialize() {
        requested = PerformanceProfile.fromString(GhostConfig.defaultProfile);
    }

    public void onRendererReady() {
        apply(requested);
    }

    public void setProfile(PerformanceProfile profile) {
        requested = profile == null ? PerformanceProfile.AUTO : profile;
        apply(requested);
    }

    private void apply(PerformanceProfile profile) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;

        effective = profile == PerformanceProfile.AUTO ? chooseAuto() : profile;
        GameSettings settings = mc.gameSettings;

        if (effective == PerformanceProfile.COMPATIBILITY) {
            settings.advancedOpengl = false;
        } else if (effective == PerformanceProfile.PERFORMANCE) {
            settings.advancedOpengl = false;
            settings.fancyGraphics = false;
            if (settings.particleSetting < 1) settings.particleSetting = 1;
            if (settings.renderDistanceChunks > GhostConfig.performanceRenderDistanceCap) {
                settings.renderDistanceChunks = GhostConfig.performanceRenderDistanceCap;
            }
        }

        LOG.info("Profile applied: requested={}, effective={}", requested, effective);
    }

    private PerformanceProfile chooseAuto() {
        if (GhostConfig.safeModeAfterUncleanSession && SessionGuard.INSTANCE.wasPreviousSessionUnclean()) {
            return PerformanceProfile.COMPATIBILITY;
        }
        RendererType renderer = CompatibilityEngine.INSTANCE.getRendererType();
        if (renderer == RendererType.SOFTWARE) return PerformanceProfile.PERFORMANCE;
        if (FiskCompat.isLoaded() && renderer != RendererType.NATIVE_OR_UNKNOWN) {
            return PerformanceProfile.COMPATIBILITY;
        }
        return PerformanceProfile.BALANCED;
    }

    public PerformanceProfile getRequested() { return requested; }
    public PerformanceProfile getEffective() { return effective; }
}
