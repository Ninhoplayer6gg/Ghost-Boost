package com.ghostboost.profile;

import com.ghostboost.config.GhostConfig;

/** Converts raw FPS/frametime data into a stable pressure signal for the adaptive controller. */
public final class FrameBudgetAnalyzer {

    public static final FrameBudgetAnalyzer INSTANCE = new FrameBudgetAnalyzer();

    private FrameBudgetState state = FrameBudgetState.HEALTHY;
    private double lastBudgetMs;

    private FrameBudgetAnalyzer() {}

    public FrameBudgetState evaluate(int fps) {
        double targetBudget = 1000D / Math.max(1, GhostConfig.targetFps);
        double p95 = FrameTimeProfiler.INSTANCE.getPercentileMs(95D);
        double p99 = FrameTimeProfiler.INSTANCE.getPercentileMs(99D);
        double stutter = FrameTimeProfiler.INSTANCE.getStutterRate();
        lastBudgetMs = targetBudget;

        boolean severe = (fps > 0 && fps < GhostConfig.targetFps * 0.70D)
            || (p99 > 0D && p99 > targetBudget * 3.0D)
            || stutter >= 0.25D;
        boolean pressured = (fps > 0 && fps < GhostConfig.targetFps)
            || (p95 > 0D && p95 > targetBudget * 1.70D)
            || stutter >= 0.12D;

        state = severe ? FrameBudgetState.SEVERE : pressured ? FrameBudgetState.PRESSURED : FrameBudgetState.HEALTHY;
        return state;
    }

    public FrameBudgetState getState() { return state; }
    public double getLastBudgetMs() { return lastBudgetMs; }
}
