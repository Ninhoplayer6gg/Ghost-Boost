package com.ghostboost.profile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;

import com.ghostboost.android.PlatformProfile;
import com.ghostboost.compat.CompatibilityEngine;
import com.ghostboost.compat.FiskCompat;
import com.ghostboost.config.GhostConfig;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/** Simple in-game benchmark that samples the real world being played. */
public final class BenchmarkManager {

    public static final BenchmarkManager INSTANCE = new BenchmarkManager();
    private static final DecimalFormat ONE = new DecimalFormat("0.0");

    private boolean running;
    private int targetSeconds;
    private int samples;
    private long fpsSum;
    private int minFps;
    private int maxFps;
    private double maxHeap;
    private double frameMsSum;
    private double p95MsSum;
    private String lastResult = "No benchmark has been completed yet.";

    private BenchmarkManager() {}

    public void start(int seconds) {
        targetSeconds = Math.max(10, Math.min(120, seconds));
        samples = 0;
        fpsSum = 0L;
        minFps = Integer.MAX_VALUE;
        maxFps = 0;
        maxHeap = 0D;
        frameMsSum = 0D;
        p95MsSum = 0D;
        running = true;
        FrameTimeProfiler.INSTANCE.reset();
    }

    public void sample(int fps, double heapRatio, double averageFrameMs, double p95FrameMs) {
        if (!running || fps <= 0) return;
        samples++;
        fpsSum += fps;
        minFps = Math.min(minFps, fps);
        maxFps = Math.max(maxFps, fps);
        maxHeap = Math.max(maxHeap, heapRatio);
        frameMsSum += averageFrameMs;
        p95MsSum += p95FrameMs;
        if (samples >= targetSeconds) finish();
    }

    private void finish() {
        running = false;
        double avgFps = samples == 0 ? 0D : (double) fpsSum / samples;
        double avgFrame = samples == 0 ? 0D : frameMsSum / samples;
        double avgP95 = samples == 0 ? 0D : p95MsSum / samples;
        int safeMin = minFps == Integer.MAX_VALUE ? 0 : minFps;

        lastResult = "GhostBoost benchmark: avg " + ONE.format(avgFps) + " FPS, min " + safeMin + ", max " + maxFps
            + ", frame " + ONE.format(avgFrame) + " ms, P95 " + ONE.format(avgP95) + " ms, peak heap "
            + Math.round(maxHeap * 100D) + "%";

        writeReport(avgFps, safeMin, maxFps, avgFrame, avgP95);
        Minecraft mc = Minecraft.getMinecraft();
        if (mc != null && mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText(EnumChatFormatting.AQUA + "GhostBoost benchmark finished."));
            mc.thePlayer.addChatMessage(new ChatComponentText(EnumChatFormatting.WHITE + lastResult));
        }
    }

    private void writeReport(double avgFps, int safeMin, int max, double avgFrame, double avgP95) {
        File dir = GhostConfig.getConfigDirectory();
        if (dir == null) return;
        File out = new File(dir, "ghostboost-last-benchmark.txt");
        FileWriter writer = null;
        try {
            writer = new FileWriter(out, false);
            writer.write("GhostBoost " + com.ghostboost.GhostBoost.VERSION + "\n");
            writer.write("Samples: " + samples + " seconds\n");
            writer.write("Average FPS: " + ONE.format(avgFps) + "\n");
            writer.write("Min FPS: " + safeMin + "\n");
            writer.write("Max FPS: " + max + "\n");
            writer.write("Average frame time: " + ONE.format(avgFrame) + " ms\n");
            writer.write("Average P95 frame time: " + ONE.format(avgP95) + " ms\n");
            writer.write("Peak heap: " + Math.round(maxHeap * 100D) + "%\n");
            writer.write("Renderer path: " + CompatibilityEngine.INSTANCE.getRendererType() + "\n");
            writer.write("GPU: " + PlatformProfile.INSTANCE.getGlRenderer() + "\n");
            writer.write("Fisk detected: " + FiskCompat.isLoaded() + " " + FiskCompat.getDetectedVersion() + "\n");
            writer.write("Profile: " + ProfileManager.INSTANCE.getEffective() + "\n");
        } catch (IOException ignored) {
            // Benchmark results still remain available in memory/chat if writing fails.
        } finally {
            if (writer != null) {
                try { writer.close(); } catch (IOException ignored) {}
            }
        }
    }

    public boolean isRunning() { return running; }
    public int getSamples() { return samples; }
    public int getTargetSeconds() { return targetSeconds; }
    public String getLastResult() { return lastResult; }
}
