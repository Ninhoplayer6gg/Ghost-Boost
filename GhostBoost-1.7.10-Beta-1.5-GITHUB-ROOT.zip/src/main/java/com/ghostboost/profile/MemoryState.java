package com.ghostboost.profile;

public enum MemoryState {
    NORMAL,
    WARNING,
    CRITICAL,
    EMERGENCY
}
