# GhostBoost 1.5.0-beta

- Added Ghost Optimization Kernel.
- Produces a smoothed 0–100 pressure score from frametime, memory state, selected profile, and Fisk content pressure.
- Particle, entity and special-render budgets now react together.
- Compatibility profile forces a neutral 1.0x kernel scale.
- Added pressure score and active budget scale to `/ghostboost status`.
